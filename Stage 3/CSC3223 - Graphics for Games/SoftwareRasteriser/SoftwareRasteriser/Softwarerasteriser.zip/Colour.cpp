#include "Colour.h"

Colour Colour::White(255,255,255,255);