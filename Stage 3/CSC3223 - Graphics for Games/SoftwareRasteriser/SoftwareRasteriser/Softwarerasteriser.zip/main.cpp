#include "SoftwareRasteriser.h"
#include "RenderObject.h"
#include "Mesh.h"
#include "Texture.h"

int main() {
	SoftwareRasteriser r(800,600);

	RenderObject *line = new RenderObject();
	line->mesh = Mesh::GenerateLine(Vector3(0, 0.0f, 0),Vector3(0.5f, 0.5f, 0));
	line->texture = Texture::TextureFromTGA("../brick.tga");
	line->modelMatrix = Matrix4::Translation(Vector3(-0.6, -0.6, -2));
	RenderObject *triangle = new RenderObject();
	triangle->mesh = Mesh::GenerateTriangle();
	triangle->texture = Texture::TextureFromTGA("../brick.tga");
	triangle->modelMatrix = Matrix4::Translation(Vector3(0, 0, -2));
	RenderObject *point = new RenderObject();
	point->mesh = Mesh::GeneratePoints(Vector3(0,0,0));

	RenderObject *testTriangle1 = new RenderObject();
	testTriangle1 -> mesh = Mesh::GenerateTriangle();
	RenderObject *testTriangle2 = new RenderObject();
	testTriangle2 -> mesh = Mesh::GenerateTriangle();
	RenderObject *testTriangle3 = new RenderObject();
	testTriangle3 -> mesh = Mesh::GenerateTriangle();

	testTriangle1->modelMatrix = Matrix4::Translation(Vector3(2, 0, -5));
	testTriangle2->modelMatrix = Matrix4::Translation(Vector3(2, 0, -25));
	testTriangle3->modelMatrix = Matrix4::Translation(Vector3(2, 0, -50));

	RenderObject *robotHead = new RenderObject();
	robotHead->mesh = Mesh::LoadMeshFile("../robotHead.asciimesh");
	robotHead->modelMatrix = Matrix4::Translation(Vector3(0, 0, -50));
	robotHead->texture = Texture::TextureFromTGA("../brick.tga");

	Matrix4 translate = Matrix4::Translation(Vector3(0.5f, 0, 0));
	Matrix4 rotate = Matrix4::Rotation(45.0f, Vector3(0, 0, 1));
	Matrix4 scale = Matrix4::Scale(Vector3(2, 0.5, 1));

	//triangle -> modelMatrix = translate * rotate * scale;

	Mesh* testTri = Mesh::GenerateTriangle();
	
	RenderObject * o1 = new RenderObject();
	RenderObject * o2 = new RenderObject();
	RenderObject * o3 = new RenderObject();
	RenderObject * o4 = new RenderObject();
	
	o1 -> mesh = testTri;
	o2 -> mesh = testTri;
	o3 -> mesh = testTri;
	o4 -> mesh = testTri;
	
	o1 -> modelMatrix = Matrix4::Translation(Vector3(-0.6, -0.6, -2));
	o2 -> modelMatrix = Matrix4::Translation(Vector3(-0.6, 0.6, -2));
	o3 -> modelMatrix = Matrix4::Translation(Vector3(0.6, -0.6, -2));
	o4 -> modelMatrix = Matrix4::Translation(Vector3(0.6, 0.6, -2));

	RenderObject *cube = new RenderObject();
	cube->mesh = Mesh::LoadMeshFile("../NewCube.asciimesh");
	cube->modelMatrix = Matrix4::Translation(Vector3(0, 0, -20));
	cube->texture = Texture::TextureFromTGA("../brick.tga");
	RenderObject *cube1 = new RenderObject();
	cube1->mesh = Mesh::LoadMeshFile("../NewCube.asciimesh");
	cube1->modelMatrix = Matrix4::Translation(Vector3(0, 0, -30));
	cube1->texture = Texture::TextureFromTGA("../brick.tga");
	RenderObject *cube2 = new RenderObject();
	cube2->mesh = Mesh::LoadMeshFile("../NewCube.asciimesh");
	cube2->modelMatrix = Matrix4::Translation(Vector3(0, 0, -50));
	cube2->texture = Texture::TextureFromTGA("../brick.tga");

	RenderObject *obscuredTri1 = new RenderObject();
	obscuredTri1->mesh = Mesh::GenerateTriangle();
	obscuredTri1->modelMatrix = Matrix4::Translation(Vector3(0, 0, -5));
	RenderObject *obscuredTri2 = new RenderObject();
	obscuredTri2->mesh = Mesh::GenerateTriangle();
	obscuredTri2->modelMatrix = Matrix4::Translation(Vector3(0, 0, -6));




	float aspect = 800.0f / 600.0f;

	Matrix4 viewMatrix;
	float yaw = 0.0f;

	r.SetProjectionMatrix(Matrix4::Perspective(1.0f, 100.0f, aspect, 45.0f));

	while(r.UpdateWindow()) {
		
		yaw += Mouse::GetRelativePosition().x;
		//viewMatrix = viewMatrix * Matrix4::RotateX(yaw);

		if (Keyboard::KeyDown(KEY_A)) {
			viewMatrix = viewMatrix *
			Matrix4::Translation(Vector3(-0.01f, 0, 0));
		}
		if (Keyboard::KeyDown(KEY_D)) {
			viewMatrix = viewMatrix *
			Matrix4::Translation(Vector3(0.01f, 0, 0));
		}
		if (Keyboard::KeyDown(KEY_W)) {
			viewMatrix = viewMatrix *
			Matrix4::Translation(Vector3(0.0, 0.01f, 0));
		}
		if (Keyboard::KeyDown(KEY_S)) {
			viewMatrix = viewMatrix *
			Matrix4::Translation(Vector3(0.0, -0.01f, 0));
		}
		if (Keyboard::KeyDown(KEY_I)) {
			viewMatrix = viewMatrix *
				Matrix4::Translation(Vector3(0.0, 0.0f, 0.1f));
		}
		if (Keyboard::KeyDown(KEY_O)) {
			viewMatrix = viewMatrix *
				Matrix4::Translation(Vector3(0.0, 0.0f, -0.1f));
		}
		if (Keyboard::KeyDown(KEY_F)) {
			r.SwitchTextureFiltering();
		}

		r.SetViewMatrix(viewMatrix);
		
		r.ClearBuffers();
		//Put draw functions here!
	
		//r.DrawObject(line);
		r.DrawObject(triangle);
		//r.DrawObject(point);
		//r.DrawObject(o1);
		//r.DrawObject(o2);
		//r.DrawObject(o3);
		//r.DrawObject(o4);
		//r.DrawObject(testTriangle1);
		//r.DrawObject(testTriangle2);
		//r.DrawObject(testTriangle3);
		//r.DrawObject(cube);
		//r.DrawObject(cube1);
		//r.DrawObject(cube2);
		//r.DrawObject(obscuredTri2);
		//r.DrawObject(obscuredTri1);
		//r.DrawObject(robotHead);


		if (Mouse::ButtonDown(MOUSE_LEFT)) {
			std::cout << "Mouse is at position: " << Mouse::GetAbsolutePosition().x << " , " << Mouse::GetAbsolutePosition().y << std::endl;
		}
		r.SwapBuffers();
		if (Keyboard::KeyDown(KEY_ESCAPE)) {
			break;
		}

	}

	delete line->mesh, triangle->mesh, point->mesh, o1->mesh,
		o2->mesh, o3->mesh, o4->mesh, cube->mesh, cube1->mesh,
		cube2->mesh, obscuredTri1->mesh, obscuredTri2->mesh, robotHead->mesh;
		
	delete line, triangle, point, o1, o2, o3, o4, cube,
		cube1, cube2, obscuredTri1, obscuredTri2, robotHead;
	
	return 0;
}